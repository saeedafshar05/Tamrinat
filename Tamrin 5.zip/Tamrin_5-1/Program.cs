﻿using System;

class Triangle
{
    private double a, b, c;

    public Triangle(double sideA, double sideB, double sideC)
    {
        if (sideA + sideB > sideC && sideA + sideC > sideB && sideB + sideC > sideA)
        {
            a = sideA;
            b = sideB;
            c = sideC;
        }
        else
        {
            throw new ArgumentException("Invalid triangle sides.");
        }
    }

    public double Perimeter()
    {
        return a + b + c;
    }

    public double Area()
    {
        double s = Perimeter() / 2; // Semi-perimeter
        return Math.Sqrt(s * (s - a) * (s - b) * (s - c));
    }
}

class Program
{
    static void Main()
    {
        try
        {
            Console.Write("Enter side A: ");
            double sideA = double.Parse(Console.ReadLine());

            Console.Write("Enter side B: ");
            double sideB = double.Parse(Console.ReadLine());

            Console.Write("Enter side C: ");
            double sideC = double.Parse(Console.ReadLine());

            Triangle triangle = new Triangle(sideA, sideB, sideC);
            Console.WriteLine("Perimeter: " + triangle.Perimeter());
            Console.WriteLine("Area: " + triangle.Area());
        }
        catch (FormatException)
        {
            Console.WriteLine("Invalid input! Please enter numeric values.");
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
}
