﻿using System;

class Program
{
    static int RecursiveMultiplication(int a, int b)
    {
        if (b == 0)
            return 0;
        else if (b > 0)
            return a + RecursiveMultiplication(a, b - 1);
        else
            return -RecursiveMultiplication(a, -b);
    }

    static void Main()
    {
        try
        {
            Console.Write("Enter first number: ");
            int num1 = int.Parse(Console.ReadLine());

            Console.Write("Enter second number: ");
            int num2 = int.Parse(Console.ReadLine());

            Console.WriteLine("Product: " + RecursiveMultiplication(num1, num2));
        }
        catch (FormatException)
        {
            Console.WriteLine("Invalid input! Please enter numeric values.");
        }
    }
}
