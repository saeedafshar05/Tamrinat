﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Enter a number:");
        int number = int.Parse(Console.ReadLine());
        if (number % 7 == 0)
        {
            Console.WriteLine("Yes");
        }
        else
        {
            Console.WriteLine(number * 3);
        }
    }
}
