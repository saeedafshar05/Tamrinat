﻿using System;

class Program
{
    static void Main()
    {
        int product = 1;
        int number;

        do
        {
            Console.WriteLine("Enter a number (0 to stop):");
            number = int.Parse(Console.ReadLine());
            if (number != 0)
            {
                product *= number;
            }
        } while (number != 0);

        Console.WriteLine("Product of entered numbers: " + product);
    }
}
