﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Enter 5 numbers:");
        int[] numbers = new int[5];
        bool found = false;
        int position = -1;
        for (int i = 0; i < 5; i++)
        {
            numbers[i] = int.Parse(Console.ReadLine());
            if (numbers[i] == 2)
            {
                found = true;
                position = i + 1;
            }
        }
        if (found)
        {
            Console.WriteLine($"Number 2 is found at position: {position}");
        }
        else
        {
            Console.WriteLine("Number 2 is not found.");
        }
    }
}
