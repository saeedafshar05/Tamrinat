﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Enter the number:");
        int number = int.Parse(Console.ReadLine());

        if (number < 10 && number % 2 == 0)
        {
            Console.WriteLine("True");
        }
    }
}
