﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Letter I:");
        DrawLetterI();
        Console.WriteLine("\nLetter E:");
        DrawLetterE();
        Console.WriteLine("\nLetter H:");
        DrawLetterH();
    }

    static void DrawLetterI()
    {
        for (int i = 0; i < 7; i++)
        {
            if (i == 0 || i == 6)
            {
                Console.WriteLine("*****");
            }
            else
            {
                Console.WriteLine("  *  ");
            }
        }
    }

    static void DrawLetterE()
    {
        for (int i = 0; i < 7; i++)
        {
            if (i == 0 || i == 3 || i == 6)
            {
                Console.WriteLine("*****");
            }
            else
            {
                Console.WriteLine("*");
            }
        }
    }

    static void DrawLetterH()
    {
        for (int i = 0; i < 7; i++)
        {
            if (i == 3)
            {
                Console.WriteLine("*****");
            }
            else
            {
                Console.WriteLine("*   *");
            }
        }
    }
}