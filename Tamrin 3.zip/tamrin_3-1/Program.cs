﻿class Program
{
    static void Main()
    {
        Console.WriteLine("Enter a number 1-7 :");
        int dayNumber = int.Parse(Console.ReadLine());

        switch (dayNumber)
        {
            case 1: Console.WriteLine("Shanbe"); break;
            case 2: Console.WriteLine("Yekshanbe"); break;
            case 3: Console.WriteLine("Doshanbe"); break;
            case 4: Console.WriteLine("Seshanbe"); break;
            case 5: Console.WriteLine("Chaharshanbe"); break;
            case 6: Console.WriteLine("Panjshanbe"); break;
            case 7: Console.WriteLine("Jome"); break;
            default: Console.WriteLine("End"); break;
        }
    }
}