﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Enter the radius of the circle:");
        double radius = Convert.ToDouble(Console.ReadLine());

        double circumference = 2 * Math.PI * radius;
        double area = Math.PI * Math.Pow(radius, 2);

        Console.WriteLine($"Circumference of the circle: {circumference}");
        Console.WriteLine($"Area of the circle: {area}");
    }
}
